package com.folioreader.model.event;

/**
 * Created by PC on 12/14/2016.
 */

public class RewindIndexEvent {
}
