package app.biblion.model;

public class DevotionModel {

    /**
     * image : Chrysanthemum.jpg
     * description : test new5
     */

    private String image;
    private String description;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
