package app.biblion.model;

public class DevotionModel {

    /**
     * description : <p>fasdgjaf&nbsp;fhasjas dfashg&nbsp;<strong> hfgjdsafdasfg dhsasjf</strong></p>\r\n\r\n<p><strong>afsdjh</strong>&nbsp;gfhagfhsgfas&nbsp;<em>hfadskfhakfhaskf&nbsp;</em></p>\r\n\r\n<p>daskjfhkaf</p>\r\n\r\n<p>dfjakfh</p>\r\n\r\n<p>&nbsp;</p>
     * image : http://frozenkitchen.in/biblion_demo/public/images/Koala.jpg
     */

    private String description;
    private String image;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
