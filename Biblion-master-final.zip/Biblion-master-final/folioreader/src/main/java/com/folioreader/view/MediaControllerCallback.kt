package com.folioreader.view

/**
 * Created by gautam on 9/5/18.
 */
interface MediaControllerCallback {
    fun play()
    fun pause()
}