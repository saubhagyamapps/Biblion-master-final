package app.biblion.interfacea;

public interface BookClick {

    public void bookClick(String id);
}
