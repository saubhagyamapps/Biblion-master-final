package com.folioreader.model.search

enum class SearchItemType {
    SEARCH_COUNT_ITEM,
    PAGE_TITLE_ITEM,
    SEARCH_RESULT_ITEM
}