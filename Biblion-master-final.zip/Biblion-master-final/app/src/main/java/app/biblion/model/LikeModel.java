package app.biblion.model;

public class LikeModel {


    /**
     * likes : 0
     */

    private int likes;

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }
}
