package app.biblion.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import app.biblion.R

class Testing : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_testing)
    }
}
