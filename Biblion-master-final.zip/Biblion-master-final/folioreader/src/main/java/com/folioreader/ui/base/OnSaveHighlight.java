package com.folioreader.ui.base;

/**
 * Created by gautam on 10/10/17.
 */

public interface OnSaveHighlight {

    void onFinished();
}
