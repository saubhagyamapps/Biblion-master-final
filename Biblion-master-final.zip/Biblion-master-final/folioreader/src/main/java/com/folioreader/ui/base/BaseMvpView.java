package com.folioreader.ui.base;

/**
 * Created by gautam on 12/6/17.
 */

public interface BaseMvpView {
    void onError();
}
