package com.folioreader.util;

import com.folioreader.model.ReadPosition;

/**
 * Created by Hrishikesh Kadam on 17/04/2018.
 */
public interface ReadPositionListener {

    void saveReadPosition(ReadPosition readPosition);
}
